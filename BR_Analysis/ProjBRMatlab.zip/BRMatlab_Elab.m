%
% BR_Matlab_Elab
%
% ver 0.2
% 
% 29/10/2019: correct cross-validation and add K-fold option
% 15/01/2020: correction bug in the use of sequential run changing test set
%             due to the use of variables defined in the precdetn run. A
%             clear step was added for variables defined in elaborate
%             correction bug Ypred vs Ycalc
%             improvement: gui now are moved in the display to avoid
%             superposition (partially)
%

%clear
%   clc


%
% Definition of blocks
% Read table from file written by BRMatlab_Prepare
%

blocks = {'V','S','R','G', ...
         'W1','W2','W3','W4','W5','W6','W7','W8', ...
         'IW1','IW2','IW3','IW4', ...
         'CW1','CW2','CW3','CW4','CW5','CW6','CW7','CW8','PSA','PSAR', ...
         'D1','D2','D3','D4','D5','D6','D7','D8', ...
         'DD1','DD2','DD3','DD4','DD5','DD6','DD7','DD8', ...
         'ID1','ID2','ID3','ID4', ...
         'CD1','CD2','CD3','CD4','CD5','CD6','CD7','CD8','HSA','PHSAR', ...
         'WO1','WO2','WO3','WO4','WO5','WO6', ...
         'WN1','WN2','WN3','WN4','WN5','WN6', ...
         'HL1','HL2','A','CP', ...
         'DRDRDR','DRDRAC','DRDRDO','DRACAC','DRACDO', ...
         'DRDODO','ACACAC','ACACDO','ACDODO','DODODO'};
     
br_blocks = {'Size','OH2','DRY','O','N1','Others'};

DataMatrixName = strcat(path,'\BRMatlab_DataMatrix.csv');
Data = readtable(DataMatrixName);
LabName = strcat(path,'\TrainingTest.txt');
Lab = readtable(LabName);

%
% Definition of the file where the results will be written
% Find the directory where the script was launched
%

[filepath,~,ext] = fileparts(mfilename('fullpath'));
name = strcat(path,'\BRMatlab_Results.txt');

%
% Define Training and Test matrices
% TrainingTest.txt: 1=Training; 0=Test
%                   Default: all training wirtten in preparation step
%

fileID = fopen(name,'w');

NObj = height(Data);

fprintf(fileID, 'File BRMatlab_Results.txt in %s\n', filepath);
fprintf(fileID, '\n\nNumber of objects: %d\n',NObj);

% Reset of variables defined by BRMatlab_Elab

clear abs_br BR BR_S cv_res
clear i j K mdl mdl_Te MTex Mx NLVs NTe NTex NTr Nx
clear pls_res prompt R2i RMSEF sig_br SSE SSR SST 
clear v ValMax ValMin x_expand XIn XTe xTe_expand xte_plot YTe XTr xtr_plot  
clear ypred YIn YTr ytr_plot YTrerr YTrNum
clear yte_plot YTeerr YTeNum yTepred

NTr = 0;
NTe = 0;

for i = 1:NObj
    
    if (Lab{i,2}==1) 
        
        NTr = NTr + 1;
        XTr(NTr,:) = Data{i,2:83};
        YTr(NTr,:) = Data{i,84};
        YTrNum(NTr) = i;
        
    else
        
        NTe = NTe + 1;
        XTe(NTe,:) = Data{i,2:83};
        YTe(NTe,:) = Data{i,84};
        YTeNum(NTe) = i;
        
    end
          
end

fprintf(fileID, '\n\nNumber of objects in the training set: %d\n',NTr);
fprintf(fileID, '\n\nNumber of objects in the test set: %d\n',NTe);
fprintf(fileID,'\n\n');

fclose(fileID);

%
% Perform PLS
%

fileID = fopen(name,'a');

prompt = 'Number of latent variables:';
NLVs = input(prompt);

fprintf(fileID,'\nNumber of LVs: %d\n',NLVs);

pls_res = pls(XTr,YTr,NLVs,'autoscaling');

% Perform CV
% To activate K fold or LOO delete the symbol %

% One Leave One Out (default)
K = length(YTr);
% K fold
%K = 4;
% Original, K=82. Probably wrong, 82 is the number of descriptor
%K = 82;
cv_res = plscv(XTr,YTr,NLVs,K,'autoscaling',1,0);

for i=1:NLVs;
    pls_res = pls(XTr,YTr,i,'autoscaling'); 
    R2i(i)=pls_res.R2;
    SST(i)=pls_res.SST;
    SSR(i)=pls_res.SSR;
    SSE(i)=pls_res.SSE;
    RMSEF(i)=pls_res.RMSEF;
end

% Plot 1: R2,Q2 vs NLVs

figure ('Name',strcat('R2,Q2 vs nLVs (LVs:', num2str(NLVs), ')'),'NumberTitle','off');
hold on
plot(1: NLVs,R2i,'k-o')
plot(1: NLVs,cv_res.Q2,'r-o')
title(strcat('R2,Q2 vs nLVs (LVs:', num2str(NLVs), 'K:', num2str(K), ')'))
legend('R2','Q2');
xlabel('Number of LVs');
ylabel('R2,Q2');
set(gca,'XLim',[0 NLVs]);
set(gca,'xtick',0:NLVs);
movegui('north')

% Print statistical data

fprintf(fileID,'\n%20s\n------------------------\n','Statistics of the model');
fprintf(fileID,'%4s %10s %10s %10s %10s %10s %10s\n','LV','R2','Q2','SST','SSR','SSE','RMSE_cv');

for i=1:NLVs
    
    fprintf(fileID,'%4d %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n',i,R2i(i),cv_res.Q2(i),SST(i),SSR(i),SSE(i),cv_res.RMSECV(i));
    
end

fprintf(fileID,'\n\n');

fclose(fileID);

% Plot2: Ycalc vs Ypred on training and test set

[Mx,Nx]=size(XTr);
x_expand=[XTr ones(Mx,1)];
ypred=x_expand*pls_res.regcoef_original_all(:,end);
mdl = fitlm(ypred,YTr);

figure('Name',strcat('Exp vs Calc (Training and Test) (LVs:', num2str(NLVs), ')'),'NumberTitle','off');

hold on

xlabel('calc');
ylabel('exp');
title(strcat('Exp vs Calc (Training and Test) (LVs:', num2str(NLVs), ')'));

ValMax = max([max(ypred) max(YTr)]);
ValMin = min([min(ypred) min(YTr)]);
plot ([ValMin ValMax],[ValMin ValMax],'k:');

xtr_plot(1) = min(ypred);
xtr_plot(2) = max(ypred);
ytr_plot(1) = xtr_plot(1) * mdl.Coefficients{2,1} + mdl.Coefficients{1,1};
ytr_plot(2) = xtr_plot(2) * mdl.Coefficients{2,1} + mdl.Coefficients{1,1};

plot(ypred, YTr, 'ko','MarkerFaceColor',[1 1 1])
plot(xtr_plot, ytr_plot,'k-')

fileID = fopen(name,'a');
fprintf(fileID,'\n\n%-30s\n-------------\n\n','Training set');
fprintf(fileID,'%-30s %10s %10s %10s\n\n','Compounds','Exp','Calc','Exp - Calc');

for i=1:NTr
   
   YTrerr(i)=YTr(i)-ypred(i);
   fprintf(fileID,'%-30s %10.4f %10.4f %10.4f\n',Data.Objects{YTrNum(i)},YTr(i),ypred(i),YTrerr(i));
    
end

if NTe > 0 

    fprintf(fileID,'\n\n%-30s\n---------\n\n','Test set');
    fprintf(fileID,'%-30s %10s %10s %10s\n\n','Compounds','Exp','Calc','Exp-Calc');
      
    [MTex,NTex]=size(XTe);
    xTe_expand=[XTe ones(MTex,1)];
    yTepred=xTe_expand*pls_res.regcoef_original_all(:,end);
    mdl_Te = fitlm(yTepred,YTe);
    
   for i=1:NTe
   
        YTeerr(i)=YTe(i)-yTepred(i);
        fprintf(fileID,'%-30s %10.4f %10.4f %10.4f\n',Data.Objects{YTeNum(i)},YTe(i),yTepred(i),YTeerr(i));
    
    end

    xte_plot(1) = min(yTepred);
    xte_plot(2) = max(yTepred);
    yte_plot(1) = xte_plot(1) * mdl_Te.Coefficients{2,1} + mdl_Te.Coefficients{1,1};
    yte_plot(2) = xte_plot(2) * mdl_Te.Coefficients{2,1} + mdl_Te.Coefficients{1,1};

    plot(yTepred, YTe,'ko','MarkerFaceColor',[0.7 0.7 0.7])
    plot(xte_plot, yte_plot,'k--')

end

legend('perfect corr','tr','tr line','te','te line');
legend('location','southeast')
movegui('northeast')

%
% Plot 3: errors in the prediction
%

figure ('Name',strcat('Error (LVs:', num2str(NLVs), ')'),'NumberTitle','off');



hold on
bar(YTrerr);
title(strcat('Error (LVs:', num2str(NLVs), ')'));
set(gca, 'XTickLabel',YTrNum, 'XTick',1:length(YTrNum));
set(gca, 'XTickLabelRotation',90,'FontSize',6)

movegui('southeast')

fclose(fileID);

%
% Plot 4: VIPs
%

fileID = fopen(name,'a');

%
% Saving VIP's values in the file of the results
%

fprintf (fileID,'\n\n%-6s %10s %10s\n', 'Descr', 'VIP', 'Coeffs');

for i=1:82
   
    fprintf(fileID,'%-6s %10.4f %10.4f\n',blocks{i}, pls_res.VIP(i), pls_res.regcoef_original(i));
    
end

figure('Name',strcat('VIP plot (LVs:', num2str(NLVs), ')'),'NumberTitle','off');

hold on
xlabel('Descriptor');
ylabel('VIP');
title(strcat('VIP plot (LVs:', num2str(NLVs), ')'));

v = bar(pls_res.VIP,'FaceColor','flat');
set(gca, 'XTickLabel',blocks, 'XTick',1:numel(blocks))
set(gca, 'XTickLabelRotation',90,'FontSize',8)

movegui('southeast')

for i=1:4
    v.CData(i,:) = [0 1 0];
end

for i=5:26
    v.CData(i,:) = [0 1 1];
end

for i=27:56
    v.CData(i,:) = [1 1 0];
end

for i=57:62
    v.CData(i,:) = [1 0 0];
end

for i=63:68
    v.CData(i,:) = [0 0 1];
end

for i=69:82
    v.CData(i,:) = [0.8 0.8 0.8];
end

% BR Analysis

BR(1) = 0;
BR_S(1,1) = 0;
BR_S(1,2) = 0;
for i=1:4
    BR(1) = BR(1) + pls_res.VIP(i)*pls_res.VIP(i);
    if (pls_res.regcoef_original_all(i,NLVs)>0)
        BR_S(1,1) = BR_S(1,1) + pls_res.VIP(i)*pls_res.VIP(i);
    else
        BR_S(1,2) = BR_S(1,2) + pls_res.VIP(i)*pls_res.VIP(i);
    end
end
BR(1) = BR(1) / 4;
BR_S(1,1) = BR_S(1,1) / 4;
BR_S(1,2) = - BR_S(1,2) / 4;

BR(2) = 0;
BR_S(2,1) = 0;
BR_S(2,2) = 0;
for i=5:26
    BR(2) = BR(2) + pls_res.VIP(i)*pls_res.VIP(i);
    if (pls_res.regcoef_original_all(i,NLVs)>=0)
        BR_S(2,1) = BR_S(2,1) + pls_res.VIP(i)*pls_res.VIP(i);
    else
        BR_S(2,2) = BR_S(2,2) + pls_res.VIP(i)*pls_res.VIP(i);
    end
end
BR(2) = BR(2) / 22;
BR_S(2,1) = BR_S(2,1) / 22;
BR_S(2,2) = - BR_S(2,2) / 22;

BR(3) = 0;
BR_S(3,1) = 0;
BR_S(3,2) = 0;
for i=27:56
    BR(3) = BR(3) + pls_res.VIP(i)*pls_res.VIP(i);
    if (pls_res.regcoef_original_all(i,NLVs)>=0)
        BR_S(3,1) = BR_S(3,1) + pls_res.VIP(i)*pls_res.VIP(i);
    else
        BR_S(3,2) = BR_S(3,2) + pls_res.VIP(i)*pls_res.VIP(i);
    end
end
BR(3) = BR(3) / 30;
BR_S(3,1) = BR_S(3,1) / 30;
BR_S(3,2) = - BR_S(3,2) / 30;

BR(4) = 0;
BR_S(4,1) = 0;
BR_S(4,2) = 0;
for i=57:62
    BR(4) = BR(4) + pls_res.VIP(i)*pls_res.VIP(i);
    if (pls_res.regcoef_original_all(i,NLVs)>=0)
        BR_S(4,1) = BR_S(4,1) + pls_res.VIP(i)*pls_res.VIP(i);
    else
        BR_S(4,2) = BR_S(4,2) + pls_res.VIP(i)*pls_res.VIP(i);
    end
end
BR(4) = BR(4) / 6;
BR_S(4,1) = BR_S(4,1) / 6;
BR_S(4,2) = - BR_S(4,2) / 6;

BR(5) = 0;
BR_S(5,1) = 0;
BR_S(5,2) = 0;
for i=63:68
    BR(5) = BR(5) + pls_res.VIP(i)*pls_res.VIP(i);
    if (pls_res.regcoef_original_all(i,NLVs)>=0)
        BR_S(5,1) = BR_S(5,1) + pls_res.VIP(i)*pls_res.VIP(i);
    else
        BR_S(5,2) = BR_S(5,2) + pls_res.VIP(i)*pls_res.VIP(i);
    end
end
BR(5) = BR(5) / 6;
BR_S(5,1) = BR_S(5,1) / 6;
BR_S(5,2) = - BR_S(5,2) / 6;

BR(6) = 0;
BR_S(6,1) = 0;
BR_S(6,2) = 0;
for i=69:82
    BR(6) = BR(6) + pls_res.VIP(i)*pls_res.VIP(i);
    if (pls_res.regcoef_original_all(i,NLVs)>=0)
        BR_S(6,1) = BR_S(6,1) + pls_res.VIP(i)*pls_res.VIP(i);
    else
        BR_S(6,2) = BR_S(6,2) + pls_res.VIP(i)*pls_res.VIP(i);
    end
end
BR(6) = BR(6) / 14;
BR_S(6,1) = BR_S(6,1) / 14;
BR_S(6,2) = - BR_S(6,2) / 14;

%
% Saving absolute BR values in the file of the results
%

fprintf (fileID, '\n\n%-6s %10s\n', 'Descr', 'Abs BR');

for i=1:6
   
    fprintf(fileID, '%-6s %10.4f \n',br_blocks{i},BR(i));
    
end

%
% Saving BR values in the file of the results
%

fprintf (fileID, '\n\n%-6s %10s %10s\n', 'Descr', 'BR(+)', 'BR(-)');

for i=1:6
   
    fprintf(fileID, '%-6s %10.4f %10.4f\n',br_blocks{i},BR_S(i,1),BR_S(i,2));
    
end

%
% Plot 5. absolute BR values
%

figure ('Name',strcat('Absolute BR plot (LVs:', num2str(NLVs), ')'),'NumberTitle','off');

hold on

xlabel('Blocks');
ylabel('BR value');
title(strcat('Absolute BR plot (LVs:', num2str(NLVs), ')'));

abs_br = bar(BR,'FaceColor','flat');
set(gca, 'XTickLabel',br_blocks, 'XTick',1:numel(br_blocks))
set(gca, 'FontSize',10)

abs_br.CData(1,:) = [0 1 0];
text(1,BR(1),num2str(BR(1),'%4.2f'),'HorizontalAlignment','center','VerticalAlignment','bottom')
abs_br.CData(2,:) = [0 1 1];
text(2,BR(2),num2str(BR(2),'%4.2f'),'HorizontalAlignment','center','VerticalAlignment','bottom')
abs_br.CData(3,:) = [1 1 0];
text(3,BR(3),num2str(BR(3),'%4.2f'),'HorizontalAlignment','center','VerticalAlignment','bottom')
abs_br.CData(4,:) = [1 0 0];
text(4,BR(4),num2str(BR(4),'%4.2f'),'HorizontalAlignment','center','VerticalAlignment','bottom')
abs_br.CData(5,:) = [0 0 1];
text(5,BR(5),num2str(BR(5),'%4.2f'),'HorizontalAlignment','center','VerticalAlignment','bottom')
abs_br.CData(6,:) = [0.8 0.8 0.8];
text(6,BR(6),num2str(BR(6),'%4.2f'),'HorizontalAlignment','center','VerticalAlignment','bottom')

movegui('southeast')

%
% Plot 6. BR values
%


figure('Name',strcat('BR plot with sign (LVs:', num2str(NLVs), ')'),'NumberTitle','off');

hold on

xlabel('Blocks');
ylabel('BR value with sign');
title(strcat('BR plot with sign (LVs:', num2str(NLVs), ')'));

sig_br = bar(BR_S,'FaceColor','flat');
set(gca, 'XTickLabel',br_blocks, 'XTick',1:numel(br_blocks))
set(gca, 'FontSize',10)
sig_br(1).CData(1,:) = [0 1 0];
sig_br(1).CData(2,:) = [0 1 1];
sig_br(1).CData(3,:) = [1 1 0];
sig_br(1).CData(4,:) = [1 0 0];
sig_br(1).CData(5,:) = [0 0 1];
sig_br(1).CData(6,:) = [0.8 0.8 0.8];
sig_br(2).CData(1,:) = [0 0.8 0];
sig_br(2).CData(2,:) = [0 0.8 0.8];
sig_br(2).CData(3,:) = [0.8 0.8 0];
sig_br(2).CData(4,:) = [0.8 0 0];
sig_br(2).CData(5,:) = [0 0 0.8];
sig_br(2).CData(6,:) = [0.6 0.6 0.6];

movegui('northwest')

fprintf(fileID,'\n\n');

fclose(fileID)