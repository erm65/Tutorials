%
% Load and check dat
%
% Interactively load data and then check the order of the obljects
% according to the order in the response vector
% The number of objects MUST be the same in descriptor matrix and in the
% response vector
%

clear;
clc;

% Input
% XIn: VS+ descriptors matrix
% YIn: Response vector
%

[file,path] = uigetfile( ...
              {'*.csv;*.txt','Comma separated'}, ...
               'Select descriptors matrix');
name = strcat(path,file);
XIn = readtable(name);

% path determine the working directory

[file,path] = uigetfile( ...
              {'*.csv;*.txt','Comma separated'}, ...
               'Select response vector', ... 
                path);


name = strcat(path,file);
YIn = readtable(name);

% Define row names (name of the compounds)

XIn.Properties.RowNames = XIn.Objects;
YIn.Properties.RowNames = YIn.Objects;

% Check that the number of rows was the same for XIn and YIn

if (height(XIn)==height(YIn))
    
    NObj = height(YIn);
    
else
    
    fprintf('STOP: the number of rows in VS+ descriptor matrix and in the response vector is different %d %d\n\n',height(XIn), height(YIn))
    return
    
end

formatSpec = 'Number of Objects in Descr Matrix %d and in Resp Matrix %d \n';
fprintf(formatSpec, height(XIn), height(YIn))


% Prepare the final matrix

block = {'V';'S';'R';'G'; ...
         'W1';'W2';'W3';'W4';'W5';'W6';'W7';'W8'; ...
         'IW1';'IW2';'IW3';'IW4'; ...
         'CW1';'CW2';'CW3';'CW4';'CW5';'CW6';'CW7';'CW8';'PSA';'PSAR'; ...
         'D1';'D2';'D3';'D4';'D5';'D6';'D7';'D8'; ...
         'DD1';'DD2';'DD3';'DD4';'DD5';'DD6';'DD7';'DD8'; ...
         'ID1';'ID2';'ID3';'ID4'; ...
         'CD1';'CD2';'CD3';'CD4';'CD5';'CD6';'CD7';'CD8';'HSA';'PHSAR'; ...
         'WO1';'WO2';'WO3';'WO4';'WO5';'WO6'; ...
         'WN1';'WN2';'WN3';'WN4';'WN5';'WN6'; ...
         'HL1';'HL2';'A';'CP'; ...
         'DRDRDR';'DRDRAC';'DRDRDO';'DRACAC';'DRACDO'; ...
         'DRDODO';'ACACAC';'ACACDO';'ACDODO';'DODODO'}
     

MatWork = table (XIn.Objects);
MatWork.Properties.VariableNames{1}='Objects';
MatWork.Properties.RowNames=XIn.Properties.RowNames
     
MatWork = [MatWork, table(XIn.(block{1}))];
MatWork.Properties.VariableNames{2}=block{1};


for j = 2:82
   
    MatWork = [MatWork, table(XIn.(block{j}))];
    MatWork.Properties.VariableNames{j+1}=block{j};
    
end

MatWork = join (MatWork, YIn)

% Define the vector with a label to use in the definition of Training and
% test set

LabVector = table(YIn.Objects, ones([NObj,1]));
LabVector.Properties.VariableNames = {'Objects', 'Lab'};

% Save the data matrix to submit to BR Analysis

FileName = strcat(path,'BRMatlab_DataMatrix.csv');
writetable(MatWork,FileName)


% Print vector of Training/Test 

FileName = strcat(path,'TrainingTest.txt');
writetable(LabVector,FileName)

