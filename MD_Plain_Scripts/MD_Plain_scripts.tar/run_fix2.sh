 .  /opt/biki/BiKiLifeSciences/enableEssentials.source
echo 0  | trjconv_mpi -f production.xtc -o production.xtc.temp.xtc -pbc nojump -s production.tpr
echo 1 0  | trjconv_mpi -f production.xtc.temp.xtc -o mv1_model1_solv.xtc -center -pbc res -ur compact -skip 1 -s production.tpr
rm -r  production.xtc.temp.xtc
