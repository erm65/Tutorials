export GMX_MAXBACKUP=-1
 .  /opt/biki/BiKiLifeSciences/enableEssentials.source
grompp_mpi -f eq-3.mdp -c eq-2.gro -p topol_cyc.top -o eq-3.tpr -maxwarn 1
nohup mpirun -n 1 mdrun_mpi -deffnm eq-3 -cpt 1 -cpo eq-3_restart1.cpt
