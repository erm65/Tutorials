export GMX_MAXBACKUP=-1
 .  /opt/biki/BiKiLifeSciences/enableEssentials.source
grompp_mpi -f production.mdp -c eq-4.gro -p topol_cyc.top -o production.tpr -maxwarn 1
nohup mpirun -n 1 mdrun_mpi -deffnm production -cpt 1 -cpo prod_restart1.cpt
