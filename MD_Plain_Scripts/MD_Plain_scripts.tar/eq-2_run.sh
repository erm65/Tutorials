export GMX_MAXBACKUP=-1
 .  /opt/biki/BiKiLifeSciences/enableEssentials.source
grompp_mpi -f eq-2.mdp -c eq-1.gro -p topol_cyc.top -o eq-2.tpr -maxwarn 1
nohup mpirun -n 1 mdrun_mpi -deffnm eq-2 -cpt 1 -cpo eq-2_restart1.cpt
