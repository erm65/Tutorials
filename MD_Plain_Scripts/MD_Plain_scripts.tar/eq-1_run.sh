export GMX_MAXBACKUP=-1
 .  /opt/biki/BiKiLifeSciences/enableEssentials.source
grompp_mpi -f eq-1.mdp -c em.gro -p topol_cyc.top -o eq-1.tpr -maxwarn 1
nohup mpirun -n 1 mdrun_mpi -deffnm eq-1 -cpt 1 -cpo eq-1_restart1.cpt
