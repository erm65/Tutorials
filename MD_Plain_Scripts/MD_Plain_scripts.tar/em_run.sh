export GMX_MAXBACKUP=-1
 .  /opt/biki/BiKiLifeSciences/enableEssentials.source
grompp_mpi -f em.mdp -c mv1_model1_solv.gro -p topol_cyc.top -o em.tpr -maxwarn 1
nohup mpirun -n 1 mdrun_mpi -deffnm em -cpt 1 -cpo em_restart1.cpt
