sh eq-1_run.sh > eq-1_run_log
sh eq-2_run.sh > eq-2_run_log
sh eq-3_run.sh > eq-3_run_log
sh eq-4_run.sh > eq-4_run_log
sh production_run.sh > production_run_log
sh run_fix2.sh
